<?php
namespace centile\hub\queue;
use pocketmine\player\Player;
use centile\hub\Loader;
use pocketmine\Server;

class QueueHandler
{

	public function __construct(public Loader $plugin, public array $queue = [])
	{
	}

	public function getAllQueued(): array
	{
		return $this->queue;
	}

	public function addToQueue(Player $player): void
	{
		$this->queue[$player->getName()] = count($this->queue) + 1;
	}

	public function removeFromQueue(Player $player): void
	{
		unset($this->queue[$player->getName()]);
	}

	public function isQueued(Player $player): bool
	{
		return isset($this->queue[$player->getName()]);
	}

	public function tick(): void
	{
		foreach (Server::getInstance()->getOnlinePlayers() as $player) {
			if (!$this->isQueued($player)) continue;
			switch ($this->queue[$player->getName()]) {
				case 1:
					if ($this->plugin->isOnline === false) {
						$player->sendMessage($this->plugin->getConfig()->get("message-notvalidServer"));
						return;
					}
					$player->sendMessage($this->plugin->getConfig()->get("q-transfer"));
					foreach ($this->queue as $name => $number) {
						$this->queue[$name] = $number - 1;
							$player->sendMessage(str_replace(["{q}"], [$number], $this->plugin->getConfig()->get("q-update")));
					}
					break;
					default:
						$player->sendActionBarMessage(str_replace(["{q}", "{total}"], [$this->queue[$player->getName()],count($this->queue)], $this->plugin->getConfig()->get("waiting_queue_tip")));
						break;
			}
		}
	}
}