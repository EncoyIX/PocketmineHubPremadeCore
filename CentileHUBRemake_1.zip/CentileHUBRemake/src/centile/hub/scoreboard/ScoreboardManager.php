<?php

namespace centile\hub\scoreboard;

use centile\hub\Loader;

class ScoreboardManager
{


    public static function tick(): void
    {
        foreach (Loader::getInstance()->getSessionManager()->getSessions() as $session) {
            if($session->getPlayer() !== null) {
                var_dump("ScoreboardManager");
                $session->update();
            }
        }
    }
}