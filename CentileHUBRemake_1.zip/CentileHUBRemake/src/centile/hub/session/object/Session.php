<?php

namespace centile\hub\session\object;

use centile\hub\item\types\EnderPearl;
use centile\hub\item\types\Servers;
use centile\hub\Loader;
use centile\hub\scoreboard\Scoreboard;
use pocketmine\player\Player;

class Session {

	public $player;

    public Scoreboard $scoreboard;

	public function __construct(Player $player)
	{
		$this->player = $player;
	}

	public function giveItems() : void {
		$this->player->getInventory()->setItem(3, new Servers());
        $this->player->getInventory()->setItem(5, new EnderPearl());
	}

    public function getPlayer(): ?Player{
        $player = \pocketmine\Server::getInstance()->getPlayerExact($this->player);
        return $player;
    }

    public function update(): void
    {
        if($this->getPlayer() === null) return;
        $sb = $this->scoreboard;
        $this->scoreboard->clear();
        $sb->addLine("§7-------------------------");
        $sb->addLine("§4§l Rank");
        $sb->addLine("§c Centile");
        $sb->addLine("§6§b");
        $sb->addLine("§4§lPlayers");
        $sb->addLine("§r§f" . Loader::getInstance()->data["online"]);
        $sb->addLine("§6§7-------------------------");
        $sb->addLine("§7§oplay.centilemc.net");
        $this->scoreboard->init();
    }


    public function getScoreboard(): Scoreboard
    {
        return $this->scoreboard;
    }
}