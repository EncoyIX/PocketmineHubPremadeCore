<?php

namespace centile\hub\session;

use centile\hub\Loader;
use centile\hub\scoreboard\ScoreboardManager;
use centile\hub\session\object\Session;
use pocketmine\player\Player;

class SessionManager {

	/** @var Session[] */
	public array $sessions = [];

	public function getSessions(): array {
        return $this->sessions;
    }

	public function createSession(Player $player): void {
        $this->sessions[$player->getName()] = new Session($player);
        Loader::getInstance()->getLogger()->info("§aAdded New player " . $player->getName() . " with name " . $player->getName());
    }

    public function getSession(Player $player): Session {
        return $this->sessions[$player->getName()];
    }

    public function removeSession(Player $player): void
    {
        unset($this->sessions[$player->getName()]);
    }
}