<?php

namespace centile\hub;

use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\inventory\InventoryTransactionEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\event\player\PlayerExhaustEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use centile\hub\scoreboard\Scoreboard;
use pocketmine\utils\TextFormat;

class HubListener implements Listener
{
    public function onJoin(PlayerJoinEvent $event): void {
       $player = $event->getPlayer();
       Loader::getInstance()->getSessionManager()->createSession($player);
       $session = Loader::getInstance()->getSessionManager()->getSession($player);
       $session->giveItems();
       $s = Scoreboard::create($player,"§4§lCentile §r§7| §r§fHub");
       $session->scoreboard = $s;
       $player->sendMessage(Loader::getInstance()->getConfig()->get("joinMessage"));
       $event->setJoinMessage("");
    }

    public function onQuit(PlayerQuitEvent $event) : void {
        $player = $event->getPlayer();
        $event->setQuitMessage("");
        Loader::getInstance()->getSessionManager()->removeSession($player);
    }

    public function onExhaust(PlayerExhaustEvent $event) : void {
        $event->cancel();
    }

    public function onEntityDamage(EntityDamageEvent $event) : void {
        $event->cancel();
    }

    public function onEntityDamagebyEntity(EntityDamageByEntityEvent $event) : void {
        $event->cancel();
    }

    public function moveItemsInInventory(InventoryTransactionEvent $event) {
        $event->cancel();
    }

    public function onChat(PlayerChatEvent $event){
        $player = $event->getPlayer();
        $playerName = $player->getName();
        $msg = $event->getMessage();
        $event->setFormat(TextFormat::colorize("&7$playerName : $msg"));
        $event->setMessage(TextFormat::colorize("&7$playerName : $msg"));
    }

}