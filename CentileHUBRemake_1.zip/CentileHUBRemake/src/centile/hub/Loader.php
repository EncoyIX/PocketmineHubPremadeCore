<?php
namespace centile\hub;
use centile\hub\entity\types\PearlEntity;
use centile\hub\item\types\EnderPearl;
use centile\hub\queue\QueueHandler;
use centile\hub\scoreboard\ScoreboardManager;
use centile\hub\session\SessionManager;
use centile\hub\tasks\UpdatePlayersTask;
use muqsit\invmenu\InvMenuHandler;
use pocketmine\data\bedrock\EntityLegacyIds;
use pocketmine\entity\EntityDataHelper;
use pocketmine\entity\EntityFactory;
use pocketmine\item\ItemFactory;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\plugin\PluginBase;
use pocketmine\scheduler\ClosureTask;
use pocketmine\utils\SingletonTrait;
use pocketmine\world\World;

final class Loader extends PluginBase
{
	use SingletonTrait;

    public SessionManager $sessionManager;

    public QueueHandler $queueHandler;

	public array $data = [
		"online" => 0,
		"server" => []
	];

	/** @var bool $isOnline */
	public bool $isOnline;

	public function onLoad(): void
	{
		self::setInstance($this);
	}

	/**
	 * @param int $players
	 */
	public function asyncCallBack(int $players): void{
		$this->data["online"] += $players + count($this->getServer()->getOnlinePlayers());
		$this->isOnline = true;
	}

	public function onEnable(): void
	{
		$this->saveDefaultConfig();
        if(!InvMenuHandler::isRegistered()) InvMenuHandler::register($this);
		$this->data["server"] = explode(":", $this->getConfig()->get("target-server"));
		ItemFactory::getInstance()->register(new EnderPearl(), true);

		EntityFactory::getInstance()->register(PearlEntity::class, function (World $world, CompoundTag $nbt): PearlEntity {
			return new PearlEntity(EntityDataHelper::parseLocation($nbt, $world), null, $nbt);
		}, ['ThrownEnderpearl', 'minecraft:ender_pearl'], EntityLegacyIds::ENDER_PEARL);

        $this->sessionManager = new SessionManager();
        $this->queueHandler = new QueueHandler($this);

        $this->getServer()->getNetwork()->setName($this->getConfig()->get("server-motd"));

        $this->getServer()->getPluginManager()->registerEvents(new HubListener(), $this);

		$this->getScheduler()->scheduleDelayedRepeatingTask(new ClosureTask(function () {
        $this->getServer()->getAsyncPool()->submitTask(new UpdatePlayersTask($this->data));
		}), 120, $this->getConfig()->get('scheduler') ?? 60);
        $this->getScheduler()->scheduleRepeatingTask(new ClosureTask(function () {
            ScoreboardManager::tick();
        }), 20);
	}

    public function getSessionManager(): SessionManager {
        return $this->sessionManager;
    }

    public function getQueueHandler(): QueueHandler {
        return $this->queueHandler;
    }
}