<?php

namespace centile\hub\inventory;

use centile\hub\Loader;
use muqsit\invmenu\InvMenu;
use muqsit\invmenu\transaction\DeterministicInvMenuTransaction;
use pocketmine\block\BlockFactory;
use pocketmine\block\BlockLegacyIds;
use pocketmine\block\VanillaBlocks;
use pocketmine\event\inventory\InventoryTransactionEvent;
use pocketmine\item\Item;
use pocketmine\item\ItemFactory;
use pocketmine\item\ItemIds;
use pocketmine\player\Player;

class ServersInventory {

	public function open(Player $player): void {
		$menu = InvMenu::create(InvMenu::TYPE_CHEST);
		$menu->setName("§cServers");

		$venomEnglish = ItemFactory::getInstance()->get(ItemIds::DYE, 14, 1);
		$venomEnglish->setCustomName("§cVenom (ENGLISH)");
		$playerCount = Loader::getInstance()->data["online"];
		$venomEnglish->setLore([
			"§7----------------------------",
			"§fVenom features custom enchants,",
			"§f/kits, and plenty of other features that",
			"§fmake HCF much more fast paced.",
			"§fThis realm is currently played",
			"§fby the English community!",
			"§fjoin the Pyro Realm for the Spanish",
			"§fcommunity!",
			"§e",
			"§4Players§7: $playerCount / 150",
			"§b",
			"§7Click to join...",
			"§e§7----------------------------"
		]);
		$menu->getInventory()->setItem(12, $venomEnglish);
        $menu->setListener(InvMenu::readonly(function (DeterministicInvMenuTransaction $transaction) use ($player): void {
            $item = $transaction->getItemClicked();
            if($item->getId() === ItemIds::DYE && $item->getMeta() === 14) {
                if(Loader::getInstance()->getQueueHandler()->isQueued($player)){
                    Loader::getInstance()->getQueueHandler()->removeFromQueue($player);
                    $player->sendMessage(Loader::getInstance()->getConfig()->get("leaveq-message"));
                    return;
                };
                $player->sendMessage(Loader::getInstance()->getConfig()->get("q-message"));
                Loader::getInstance()->getQueueHandler()->addToQueue($player);
            }
        }));
        $menu->send($player);
	}
}