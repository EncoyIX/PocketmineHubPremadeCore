<?php

namespace centile\hub\item;

use pocketmine\item\Item;
use pocketmine\item\ItemIdentifier;

class ItemRegistry extends Item {
	public function __construct(ItemIdentifier $identifier, string $name, array $lore)
	{
		$this->setCustomName($name);
		$this->setLore($lore);
		parent::__construct($identifier, $name);
	}
}