<?php

namespace centile\hub\item\types;

use centile\hub\inventory\ServersInventory;
use centile\hub\item\ItemRegistry;
use pocketmine\item\ItemIdentifier;
use pocketmine\item\ItemIds;
use pocketmine\item\ItemUseResult;
use pocketmine\math\Vector3;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat;

class Servers extends ItemRegistry {

	public function __construct()
	{
		parent::__construct(new ItemIdentifier(ItemIds::NETHER_STAR, 0), TextFormat::RESET . TextFormat::BOLD .TextFormat::RED . "Servers ",
			[
				"§r§7Right click to join our discord!"
			]
		);
	}

	public function onClickAir(Player $player, Vector3 $vector) : ItemUseResult {
		$inventory = new ServersInventory();
		$inventory->open($player);
		return ItemUseResult::SUCCESS();
	}
}