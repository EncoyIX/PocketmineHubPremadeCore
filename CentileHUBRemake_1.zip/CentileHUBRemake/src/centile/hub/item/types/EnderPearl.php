<?php
namespace centile\hub\item\types;

use centile\hub\entity\types\PearlEntity;
use pocketmine\entity\Location;
use pocketmine\entity\projectile\Throwable;
use pocketmine\item\ItemIdentifier;
use pocketmine\item\ItemIds;
use pocketmine\item\ProjectileItem;
use pocketmine\player\Player;

class EnderPearl extends ProjectileItem {

	public function __construct()
	{
		parent::__construct(new ItemIdentifier(ItemIds::ENDER_PEARL,0),"Ender Pearl");
	}

	public function getThrowForce(): float
	{
		return 1.6;
	}

	public function getMaxStackSize(): int
	{
		return 16;
	}

	protected function createEntity(Location $location, Player $thrower): Throwable
	{
		return new PearlEntity($location, $thrower);
	}
}