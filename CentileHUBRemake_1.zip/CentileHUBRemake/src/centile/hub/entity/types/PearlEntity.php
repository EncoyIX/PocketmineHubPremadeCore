<?php
namespace centile\hub\entity\types;
use pocketmine\entity\Entity;
use pocketmine\entity\EntitySizeInfo;
use pocketmine\entity\Location;
use pocketmine\entity\projectile\Throwable;
use pocketmine\event\entity\ProjectileHitBlockEvent;
use pocketmine\event\entity\ProjectileHitEvent;
use pocketmine\math\Vector3;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\network\mcpe\protocol\SetActorLinkPacket;
use pocketmine\network\mcpe\protocol\types\entity\EntityIds;
use pocketmine\network\mcpe\protocol\types\entity\EntityLink;
use pocketmine\network\mcpe\protocol\types\entity\EntityMetadataFlags;
use pocketmine\network\mcpe\protocol\types\entity\EntityMetadataProperties;
use pocketmine\player\Player;

class PearlEntity extends Throwable
{
	public Player|null $rider = null;

	public $gravity = 0.027;
	public $drag = 0.01;

	public function __construct(Location $location, ?Entity $shootingEntity, ?CompoundTag $nbt = null)
	{
		if(!$shootingEntity instanceof Player) return;
		parent::__construct($location, $shootingEntity, $nbt);
	}

	public static function getNetworkTypeId(): string
	{
		return EntityIds::ENDER_PEARL;
	}

	public function getInitialSizeInfo(): EntitySizeInfo
	{
		return new EntitySizeInfo(0.25, 0.25);
	}


	//credits to brokiem/SimplePets
	public function setRiding(Player $player): void
	{
		$player->getNetworkProperties()->setGenericFlag(EntityMetadataFlags::RIDING, true);
		$player->getNetworkProperties()->setVector3(EntityMetadataProperties::RIDER_SEAT_POSITION, new Vector3(0, $this->getInitialSizeInfo()->getHeight() + 1, 0));
		$pk = new SetActorLinkPacket();
		$pk->link = new EntityLink($this->getId(), $player->getId(), EntityLink::TYPE_RIDER, false, true);
		$player->getServer()->broadcastPackets($this->getViewers(), [$pk]);
		$this->rider = $player;
	}

	protected function onHit(ProjectileHitEvent $event): void
	{
		$owner = $this->getOwningEntity();
		if (!$owner instanceof Player) {
			return;
		}
		$hitResult = $event->getRayTraceResult();
		$pos = $hitResult->getHitVector();
		$owner->teleport($pos);
		if($this->rider !== null){ $this->unride($owner);}
		$this->flagForDespawn();
	}


	public function unride(Player $player): void
	{
		if ($this->rider !== null) {
			if ($this->getRider() !== null) {
				$this->getRider()->getNetworkProperties()->setGenericFlag(EntityMetadataFlags::RIDING, false);
				$this->getRider()->getNetworkProperties()->setVector3(EntityMetadataProperties::RIDER_SEAT_POSITION, new Vector3(0, 0, 0));

				$pk = new SetActorLinkPacket();
				$pk->link = new EntityLink($this->getId(), $this->getRider()->getId(), EntityLink::TYPE_REMOVE, false, true);
				$this->getRider()->getServer()->broadcastPackets($this->getViewers(), [$pk]);
			}

			$this->rider = null;
		}
	}

	public function onUpdate(int $currentTick): bool
	{
		if($this->getOwningEntity() !== null){
			$this->setRiding($this->getOwningEntity());
		}
		if($this->isFlaggedForDespawn()){
			if($this->rider !== null){
				$this->unride($this->rider);
			}
		}
		return parent::onUpdate($currentTick);
	}


	public function getRider():? Player
	{
		return $this->rider;
	}
}