<?php
namespace libpmquery;

class PmQueryException extends \Exception{
}